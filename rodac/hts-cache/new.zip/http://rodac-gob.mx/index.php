<!DOCTYPE html>
<html lang="es_mx">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <META name="keyword" content="rodac, sep, oficial, preparatoria, validez, validacion, certificado,dgair">
  <meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Registro Oficial de Documentos Académicos y Certificación (RODAC)| SEP | RODAC |  Consulta Publica RODAC</title>

  <meta name="theme-color" content="#393C3E">
  <meta name="description" content="Sitio Oficial de la Secretaría de Educación Pública (SEP) para realizar la consulta de Folio RODAC de certificados y documentos emitidos por el Sistema Educativo Nacional.">
  <meta name="og:title" property="og:title" content="CONSULTA DE CERTIFICADOS SEP">
    
  <meta name="article:section" content="Educacion">
  <meta name="article:author" content="Secretaria de Educacion Publica">
  <meta name="article:tag" content="RODAC SEP Consulta Documentos">
	<link href="CDN/favicon.ico" rel="shortcut icon" />
	<link href="CDN/main.css" rel="stylesheet" /><!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
         <![endif]-->
</head>
<body class="pace-done">
<section>
<nav class="navbar navbar-inverse sub-navbar navbar-fixed-top">
<div class="container">
<div class="navbar-header"><button class="navbar-toggle collapsed" data-target="#subenlaces" data-toggle="collapse" type="button"><span class="sr-only">Interruptor de Navegaci&oacute;n</span></button><a class="navbar-brand" href="/">CONSULTA SEP RODAC</a></div>

<div class="collapse navbar-collapse" id="subenlaces">
<ul class="nav navbar-nav navbar-right">
	<li><a href="/index.php">Inicio</a></li>
	<li><a href="/verificacion.php">Consulta RODAC</a></li>
  <li><a href="/mision.php">Misi&oacute;n y Visi&oacute;n</a></li>
  <li><a href="/">CURP</a></li>
</ul>
</div>
</div>
</nav>
</section>
<br>
<br>
<section>
<div>
<div class="section" data-type="background" id-identity="12536" style=" background-size: cover; height: 100%; width: 100%; text-align: center;"><img class="responsive" src="IMG/RODAC_Header2.png" alt="fondo RODAC" style=" background-size: cover; height: 100%; width: 100%; text-align: center;" /></div>
</div>
</section>

<main class="page">
<section>
<div class="container">
<section class="estructura" id="744" style="">
<div class="container">
<div class="bottom-buffer">
<h1>RODAC</h1>
<h4>SEP RODAC OFICIAL</h4>
<br/>
<h2>&iquest;Que es RODAC?</h2>

<hr class="red" /></div>

<div class="slider-articles" id="sliderArticles">
<p align="justify">RODAC Es una plataforma que permite verificar los documentos emitidos por las diferentes instituciones de los diferentes niveles educativos de M&eacute;xico con el prop&oacute;sito de garantizar seguridad sobre los estudios realizados as&iacute; como una verificaci&oacute;n &aacute;gil y oportuna del historial electr&oacute;nico que se integra a trav&eacute;s del paso de los alumnos. RODAC es un portal seguro que cumple con los más altos estandares establecidos por las dependencias federales educativas.</p>
</div>
&nbsp;

<h2>¿Como consultar la validez de un documento oficial emitido por el Sistema Educativo Nacional en el Sistema RODAC?</h2>

<hr class="red" /></div>


<section id=6037>
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,600" rel="stylesheet">
<style>body { font-family: "Montserrat"}h1, h2, h3 { font-weight: 400;}h4 { font-weight: 200;}.img-responsive { margin: auto;}.pasitos { width: 150px; height: auto; margin-top: 18px;}.secciones-home { min-height: 64px; margin-bottom: 12px;}.boton-rojo {background: #A42145;color: #fff;margin: 12px auto;min-height: 82px;border-radius: 50px;padding: 16px 10px 12px;font-weight: 600;max-width: 280px; }.boton-rojo:hover,.boton-rojo:focus,.boton-rojo:active,.boton-rojo.active { background: #941135;}.boton-rojo a { text-decoration: none; color: #fff; }.flechita { font-size: 50px; margin-top: 64px; text-align: center; color:#A42145;}.paso-institucion { padding: 30px 0;} .numerito { background: #A42145; color: #fff; width: 32px; height: 32px; border-radius: 50%; text-align: center; padding-top: 5px; position: absolute; top: 23px; left: 21px; display: none; }.red-line { border-left:#a22244 3px solid; min-height:70px; padding-left: 12px;} @media (max-width: 991px) {/*.flag-banner { height: 320px;} .flag-banner img { display:none; height: 320px; }*/}#subenlaces, </style>
<section class="section section-intro flag-banner" style="background-image:url(img/RODAC_Header2.png);">
  <h2 class="hidden">Cédulas Profesionales | Dirección General de Profesiones | Trámites</h2>
</section>
<div class="container">

<!--acaempiza-->
  

<div class="row text-center  top-buffer">
        <div class="col-md-4">
          <article class="post">
            <div class="">
              <a href="verificacion.php">
              <img class="img img-responsive redondes-img" src="https://www.gob.mx/cms/uploads/image/file/498707/inicio1.png" title="Sección Profesionistas">
            </a>
            </div>
            <h3 class="secciones-home">Consulta RODAC</h3>
            <div class="boton-rojo">
              <a href="verificacion.php">Consulta tus Documentos RODAC</a>
            </div> 
          </article>
        </div>
                    <div class="col-md-4">
              <article class="post">
                <div class="">
                   <a href="profesional.php">
                  <img class="img img-responsive redondes-img" src="https://www.gob.mx/cms/uploads/image/file/498708/inicio2.png" title="Sección Instituciones educativas">
                </a>
                </div>
                <h3 class="secciones-home">Consulta SIGED</h3>
                <div class="boton-rojo">
                <a href="">Consulta tus Documentos SIGED</a>
                </div>
              </article>
            </div>


        <div class="col-md-4">
          <article class="post">
            <div class="">
              <a href="profesional.php">
              <img class="img img-responsive redondes-img" src="https://www.gob.mx/cms/uploads/image/file/498709/inicio3.png" title="Sección Registro Nacional de Profesionistas">
            </a>
            </div>
            <h3 class="secciones-home">Consulta de <br>CURP</h3>
            <div class="boton-rojo">
            <a href="">Realiza la consulta<br>CURP</a>
            </div>
          </article>
        </div>
</div>



<!--aca termina-->
</div>
    </section>

</div>

<div aria-hidden="true" class="hidden-xs font-changer internal print" tabindex="-1">
<button class="inc-font font-modifier">Aa+</button>
<button class="dec-font font-modifier">Aa-</button>
</div>
<div class="space_bottom clearfix vertical-buffer"></div>


<div class="col-md-12 slider-articles" id="sliderArticles">
<div class="col-md-7">
<div>
</div>
</div>
</div>


</section>
</div>
</section>
<br>
<br>




&nbsp;</main>
<script src="CDN/gobmx.js"></script><script type="text/javascript">
  $gmx(document).ready(function() {
  $('[data-toggle="tooltip"]').tooltip();
  });
</script></body>
</script></html>