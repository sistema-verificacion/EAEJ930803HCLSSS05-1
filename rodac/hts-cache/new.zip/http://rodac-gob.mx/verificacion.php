<!DOCTYPE html>
<html lang="es_mx">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <META name="keyword" content="rodac, sep, oficial, preparatoria, validez, validacion, certificado,dgair">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Consulta Publica RODAC SEP</title>

  <meta name="theme-color" content="#393C3E">
  <meta name="description" content="Sitio Oficial de la Secretaría de Educación Pública (SEP) para realizar la consulta de Folio RODAC de certificados y documentos emitidos por el Sistema Educativo Nacional.">
  <meta name="og:title" property="og:title" content="CONSULTA DE CERTIFICADOS SEP">

  <meta name="article:section" content="Educacion">
  <meta name="article:author" content="Secretaria de Educacion Publica">
  <meta name="article:tag" content="RODAC SEP Consulta Documentos">
  <link href="CDN/favicon.ico" rel="shortcut icon" />
  <link href="CDN/main.css" rel="stylesheet" />
  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
         <![endif]-->
</head>

<body class="pace-done">
  <section>
    <nav class="navbar navbar-inverse sub-navbar navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#subenlaces">
            <span class="sr-only">Interruptor de Navegacion</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/">RODAC</a>
        </div>
        <div class="collapse navbar-collapse" id="subenlaces">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="/index.php">Inicio</a></li>
            <li><a href="/verificacion.php">Consulta RODAC</a></li>
            <li><a href="/mision.php">Misi&oacute;n y Visi&oacute;n</a></li>
          </ul>
        </div>
      </div>
    </nav>
  </section>
  <br>
  <section>
    <div>
      <div class="section" data-type="background" id-identity="12536" style=" background-size: cover; height: 100%; width: 100%; text-align: center;">
        <img class="responsive" src="IMG/RODAC_Header2.png" style=" background-size: cover; height: 100%; width: 100%; text-align: center;">
      </div>
    </div>
  </section>

  <main class="page">
    <section>
      <div class="container">
        <div class="row">

          <div class="col-md-12">
            <ol class="breadcrumb">
              <li><a href="/"><i class="icon icon-home"></i></a></li>
              <li><a href="/">Inicio</a></li>
              <li class="active">Consulta RODAC</li>
            </ol>
            <h3></h3>
            <hr class="red">
          </div>
          

          <tbody id="tbody">
                          <tr>
                <td colspan="5" style="text-align:center">
            
                <div class="col-md-12">
                            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#tab-01">Consulta Publica RODAC</a></li>
              </ul>
              <div class="tab-content">
                <div class="tab-pane active" id="tab-01">
                  <div class="example">

                    <h6>Para garantizar la validez oficial de un Certificado Emitido por el Sistema Educativo Nacional ingresa el folio RODAC y tu CURP en el cuadro de consulta; esto generara la busqueda del registro en la plataforma RODAC</h6>
                    <br>
                    <br>
                    <form class="form-horizontal" method="post" action>
                      <div class="form-group">
                        <label class="col-sm-2 control-label" for>FOLIO:</label>
                        <div class="col-sm-10">
                          <input class="form-control" name="home_folio" id="home_folio" type="varchar" maxlength="100" required pattern="[A-Za-z0-9]+" title="No se permite los espacios.">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-2 control-label" for>CURP:</label>
                        <div class="col-sm-10">
                          <input class="form-control" name="home_curp" id="home_curp" type="varchar" maxlength="100" required pattern="[A-Za-z0-9]+" title="No se permite los espacios.">
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                          <button class="btn btn-primary pull-right" name="srch_btn" type="submit" value="ok">Buscar registro en RODAC &nbsp;</span></button>
                        </div>
                      </div>
                  </div>
                </div>
                </form>
              </div>
              <br>
              <br>
              <div class="row">
                <div class="col-md-12">
                  <div class="alert alert-info">
                    <p> Los certificados estarán disponibles para su consulta un día después de su emisión.</p>
                  </div>
                </div>
              </div>
            </div>
                </td>
              </tr>
                      </tbody>



          <br>
          <br>
          <br>
          <br>
        </div>


      </div>
      </div>
      <br>
      </div>

    </section>
  </main>


  <div>
    <section>


      <script src="CDN/gobmx.js"></script>

      </script>
      <script type="text/javascript">
        $gmx(document).ready(function() {
          $('[data-toggle="tooltip"]').tooltip();
        });
      </script>
</body>

</html>