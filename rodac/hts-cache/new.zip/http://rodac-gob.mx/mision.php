<!DOCTYPE html>
<html lang="es_mx">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <META name="keyword" content="rodac, sep, oficial, preparatoria, validez, validacion, certificado,dgair">
  <meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Misi&oacute;n y Visi&oacute;n</title>

  <meta name="theme-color" content="#393C3E">
  <meta name="description" content="Sitio Oficial de la Secretaría de Educación Pública (SEP) para realizar la consulta de Folio RODAC de certificados y documentos emitidos por el Sistema Educativo Nacional.">
  <meta name="og:title" property="og:title" content="CONSULTA DE CERTIFICADOS SEP">
    
  <meta name="article:section" content="Educacion">
  <meta name="article:author" content="Secretaria de Educacion Publica">
  <meta name="article:tag" content="RODAC SEP Consulta Documentos">
	<link href="CDN/favicon.ico" rel="shortcut icon" />
	<link href="CDN/main.css" rel="stylesheet" /><!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
         <![endif]-->
</head>
<body class="pace-done">

<section>
<nav class="navbar navbar-inverse sub-navbar navbar-fixed-top">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#subenlaces">
<span class="sr-only">Interruptor de Navegación</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="/">RODAC</a>
</div>
<div class="collapse navbar-collapse" id="subenlaces">
<ul class="nav navbar-nav navbar-right">
  <li><a href="/index.php">Inicio</a></li>
  <li><a href="/verificacion.php">Consulta RODAC</a></li>
  <li><a href="/mision.php">Misi&oacute;n y Visi&oacute;n</a></li>
  <li><a href="/profesional.php">Cedula Profesional</a></li>
</ul>

</div>
</div>
</nav>
<br>
</section>

<section>
<div>
<div class="section" data-type="background" id-identity="12536" style=" background-size: cover; height: 100%; width: 100%; text-align: center;">
<img class="responsive" src="IMG/RODAC_Header2.png" style=" background-size: cover; height: 100%; width: 100%; text-align: center;">
</div>
</div>
</section>

<main class="page">
<section>
<div class="container">
<div class="row">
<div class="col-md-12">
<ol class="breadcrumb">
<li><a href="/"><i class="icon icon-home"></i></a></li>
<li><a href="/">Inicio</a></li>
<li class="active">RODAC</li>
</ol>
<h1>Misión y Visión</h1>
<hr class="red">
<h4>Misión</h4>
<p>Promover una administración escolar eficiente; facilitar la participación de los particulares en la prestación de los servicios ; promover políticas que agilicen la movilidad académica.</p>
<h4></h4>
<h4>Visión</h4>
<p>Conformar una unidad administrativa eficiente, que proponga y evalúe los proyectos normativos.</p>
<p></p>
<p></p>
</div>
</div>
<br>
</div>
</section>
</main>
<script src="CDN/gobmx.js"></script><script type="text/javascript">
  $gmx(document).ready(function() {
  $('[data-toggle="tooltip"]').tooltip();
  });
</script></body>
</script></html>